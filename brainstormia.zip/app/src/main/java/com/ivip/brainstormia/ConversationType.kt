package com.example.brainstormia

enum class ConversationType {
    PERSONAL,
    EMOTIONAL,
    THERAPEUTIC,
    HIGHLIGHTED,
    GENERAL
}