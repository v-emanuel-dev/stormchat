package com.ivip.brainstormia.navigation

object Routes {
    const val AUTH = "auth"
    const val MAIN = "main"
    const val RESET_PASSWORD = "reset_password"
}
